<?php
$db=mysqli_connect("localhost","admin","12345");//підключаємось до хоста
mysqli_select_db($db,"doberman");//підключаємось до бази даних
?>