

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Rubik:wght@300&family=Ysabeau:wght@200&display=swap" rel="stylesheet">
<link rel="shortcut icon" href="img/dobericon.ico">
    <meta charset="UTF-8">
    <title>DOBERMAN</title>
</head>
<body>
   
   <table align='center' class="table">
       <tr>
           <td class="header">
               <h1><img src="img/icon.png" alt=""> DOBERMAN</h1>
           </td>
       </tr>
       
       <tr>
           <td class="explain">
            <h4 class="about"> Ми - сервіс DOBERMAN, допоможемо відновити загублені в тій чи іншій ситуації зв’язки.  Працюємо по всій Україні з початку бойових дій. Наші волонтери роблять все, щоб допомогти людям знайти одне одного. </h4> 
            <button class="btn" type="button" name="button"><b><a href="finder_introduce_form.php">Повідомити про втрачену людину</a></b></button>  
            <button class="btn" type="button" name="button"><b><a     href="helper_search_form.php">Допомогти знайти</a></b></button>
            <h4>Допомога надається безкоштовно. </h4>
           </td>
       </tr>
       
       <tr>
           <td class="team">
               <h3>КОМАНДА</h3>
               <h5>Наша команда складається з групи волонтерів - колишніх працівників кримінальних структур, які виявили бажання допомогти людям у такий непростий час.</h5>
               <button class="btn" type="button" name="button"><b><a href="executors.php">Повний Список</a></b></button>
           </td>
       </tr> 
       
       <tr>
           <td class="footer">
               <p>© 2024 </p>
               <p>+380 XX XXX XX XX</p>
           </td>
       </tr>
   </table>
    
</body>
</html>